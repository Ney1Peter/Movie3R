# Build instructions

Set `main.tex` as the Overleaf root and use pdfLaTeX with BibTeX:

```text
pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
```

Equivalently:

```text
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
```

The archive has no machine-specific TeX dependency. It includes
`references.bib`, the ICLR bibliography style, and `main.bbl` as a fallback.
Chinese translations are ordinary LaTeX comments and require no CJK package.

## v050 validation

- US-Letter output;
- nine-page main scientific paper, including the complete Conclusion;
- Method ends on page 6 and Conclusion on page 9;
- statements on page 10 and References from page 11;
- a dedicated appendix table of contents appears on page 13 and lists the five
  supplementary sections plus the seven additional-experiment subsections;
- supplementary material is organized into five sections and ends on page 30;
- rendered tables are numbered continuously from Table 1 to Table 28;
- JOSH is reported as an offline full-sequence reference on all 307 primary
  streams, with 302 native outputs, 292 W/WA-valid streams, and 302 ATE-valid
  streams; failures and metrics favouring JOSH remain visible;
- OnlineHMR supplementary evidence covers 354 additional fixed streams with
  all failures, finite support, and complete-denominator Coverage retained;
- no undefined citations or references;
- no fatal errors or overfull boxes in the compiled manuscript;
- no rendered drafting placeholders, local absolute paths, usernames, or old
  reader-facing Bridge3R/Strict Human3R terminology;
- complete build validated locally with Tectonic; final submission should also
  be rebuilt once in Overleaf/pdfLaTeX to confirm its font environment.
