# Figure provenance

All figures are anonymous and contain no experiment-version identifiers.

| File | Source | Data driven? | Scope |
|---|---|---:|---|
| teaser.pdf / .svg | `Shot3R_teaser_article_figure1_editable.pptx`, copied from the supplied `Shot3R_teaser_sparse_motion_editable.pptx` with only the visible labels updated to match the paper terminology. The top and bottom RGB panels are source frames from a temporally concatenated EgoHumans single-view-shot sequence; the central point-cloud/person/camera composition is explicitly schematic and retains the source deck's illustrative assets. | Partly | Figure 1 overview of streaming multi-shot input, cuts, shared world-frame intent, and persistent identity colours. The central composition is not a raw prediction or quantitative result. |
| method.pdf / .svg | `Shot3R_pipeline_Harmony4D_article_figure2_editable.pptx`, adapted from the supplied editable v3 deck; the slide follows the causal state protocol: temporary history-conditioned alignment, reinitialized recurrence, prediction-only association, shared camera--human transform, and streaming output. | No | Editable method schematic. The output panel is explicitly a schematic world-frame illustration and makes no quantitative or visual-performance claim. |
| egohumans_angle_strata.pdf / .svg | `tools/plot_egohumans_angle_strata.py` applied to the case-level formal-90 result file, with capture-cluster bootstrap. | Yes | W-MPJPE and IDF1 as a function of camera-pair angle. It contains no RGB, ground truth rendering, evaluator annotation, or synthesized image. |
| qualitative_real_large_view.pdf / .svg | Real EgoHumans RGB and method-native outputs selected by the recorded metric rule; the SVG supplies editable layout and callouts. | Yes | Archived qualitative comparison retained for audit; it is not the current Figure 1 asset. No observation or reconstruction panel is synthesized. |

The angle-stratified plot is a pre-specified aggregate analysis; its
machine-readable means and intervals are stored next to the manuscript table
artifact. Its publication PDF is exported from the retained SVG with CairoSVG
so that the submission contains no Type-3 glyphs; this export changes no plot
data or geometry. The qualitative teaser is explicitly metric-selected rather than
representative, and its separate provenance record gives the selection rule,
panel hashes, and method-interface boundaries.

The editable Figure 2 source is retained next to the manuscript figures. The
visible output labels use the paper terminology ``World-frame output'' and
``Schematic illustration''; the original calibrated v3 deck remains preserved
in the publication asset directory.
