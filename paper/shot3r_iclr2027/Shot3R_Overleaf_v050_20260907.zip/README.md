# Shot3R ICLR 2027 manuscript — v050

`main.tex` is the only compilation root. It produces one anonymous US-Letter
PDF containing the nine-page main scientific paper, required statements,
references, and supplementary material.

The paper presents:

- streaming multi-person 4D reconstruction from sequential monocular shots;
- a separation between temporary inter-shot alignment information and the
  recurrent state propagated through the new shot;
- prediction-based person association and one shared camera--human world
  transform;
- paired Human3R--Shot3R evidence on EgoBody, EgoHumans, and Harmony4D;
- comparisons with public methods including OnlineHMR and an offline
  full-sequence JOSH reference on all three primary datasets;
- viewpoint-stratified, person-association, detector, and runtime
  analyses.

Compared with v049, this draft removes `feed-forward` from the abstract's
description of Shot3R. The abstract now emphasizes the online streaming
setting, while `feed-forward` remains in Related Work where it describes a
method category. No method behavior, experiment, or table value is changed.

Rewritten English main-paper paragraphs and captions are preceded by Chinese
`% 中文：...` comments. These comments remain visible in Overleaf source but
are omitted from the PDF.

See `BUILD.md` for compilation and validation. Rendered reader-facing content
uses Shot3R and Human3R consistently.
