# Manuscript changelog

## v050 supplementary-material audit (continuation)

- Clarified that the two annotated-boundary rows are controlled diagnostics,
  not deployable settings, and removed the stale JOSH3R row from the related-
  method scope table because JOSH is already evaluated in the main table.
- Made the EgoHumans association table self-contained by naming evaluable
  clips and evaluator-excluded pair slots explicitly.
- Corrected dataset-specific camera metrics: EgoBody uses ATE-Sim3 and
  EgoHumans uses ATE-SE3; clarified the mixed-dataset viewpoint table and the
  Harmony4D boundary-translation column.
- Replaced Figure 2 with the terminology-checked editable pipeline deck,
  exported its vector PDF/SVG, and marked the calibration-assisted output
  panel as a schematic world-frame illustration.
- Preserved all methods, checkpoints, protocols, numerical values, and the
  9-page main-paper / 30-page complete-manuscript layout.

## v044_20260907_alignment_terminology

- Unified the temporary route as the history-conditioned alignment path and
  its learnable component as the shot-alignment module.
- Reserved alignment-token terminology for the module's three internal token
  representations and removed competing correction-token and relation-module
  aliases from reader-facing prose.
- Updated the editable method schematic and its PDF export to use the same
  direct state-role description.
- Preserved all v043 methods, formula content, experiments, and table values.

## v043_20260907_contribution_reframing

- Reorganized the contribution list into the state conflict, the Shot3R
  realization, and the corresponding reconstruction/runtime evidence.
- Replaced the broad ``general principle'' and ``information lifetimes''
  wording with the concrete distinction between temporary alignment history
  and the recurrent state propagated through the new shot.
- Preserved all v042 methods, formulas, experimental results, tables, and
  figures.

## v042_20260907_introduction_and_runtime_audit

- Reframed the Introduction around streaming multi-person reconstruction from
  sequential monocular shots and the discontinuities created by shot changes.
- Positioned existing multi-shot processing against the desired streaming
  setting before introducing the state conflict at a shot boundary.
- Clarified the central observation: historical state may be read temporarily
  for alignment but should not control recurrent reconstruction in the new
  shot.
- Preserved all v041 methods, experimental results, tables, and figures.

## v041_20260906_josh_three_dataset_integration

- Added the completed JOSH offline full-sequence reference on all 129
  EgoBody, 90 EgoHumans, and 88 Harmony4D inputs without changing any prior
  method or result.
- Expanded the main comparison table with the audited EgoBody and Harmony4D
  JOSH rows and preserved each metric's valid support.
- Rewrote only the JOSH-related comparison text to distinguish reconstruction
  accuracy, identity, Coverage, temporal access, and native failures.
- Added supplementary execution/support accounting for all 307 streams and
  retained both Shot3R- and JOSH-favouring outcomes.
- Added versioned machine-readable JOSH summaries and independent audits for
  the two newly completed datasets.
- Compactly rephrased the unchanged conclusion claim so that the complete
  conclusion and limitation remain on main-paper page 9.

## v039_20260906_onlinehmr_extension_integration

- Integrated the verified 354-stream OnlineHMR supplementary campaign while
  preserving all existing results and artifacts.
- Added the strongest repeated-transition AIST++ paired result to the main
  paper, together with the complementary local and boundary outcome.
- Added OnlineHMR to the AIST++ single/repeated-cut, MVHuman, and Harmony4D
  three-shot supplementary tables.
- Added AIST++ paired intervals and MVHuman viewpoint-stratified paired
  results, with complete failure and support accounting.
- Preserved OnlineHMR-favouring metrics, MVHuman early triggers, and the small
  Harmony4D multi-cut denominator in the rendered interpretation.

## v038_20260906_baseline_scope_and_josh_audit

- Added JOSH and CVPR 2022 Multishot to the method positioning.
- Replaced the broad "code unavailable" explanation for HumanMM and
  Multi-THuMBS with a precise account of missing executable inference,
  pretrained models, and complete same-protocol settings.
- Added a supplementary capability and executability table for related
  methods absent from the same-input numerical tables.
- Recorded the JOSH Gate A/B result: all available dependencies and models
  were audited, but the official demo stopped at gated SAM3 access before
  producing predictions; no development or test sample was consumed.
- Preserved all v037 experimental artifacts, numerical tables, figures, and
  the nine-page main-paper layout.

## v037_20260906_supplement_revision

- Reorganized the supplement into five coherent sections and ordered the
  additional experiments by research question.
- Reduced the rendered table set from 36 to 24 without changing retained
  measurements.
- Removed repeated, all-constant, and one-row tables; combined closely related
  results into compact presentations.
- Simplified captions and removed internal audit/manifest terminology from
  rendered supplementary prose.
- Added colored method-property and component indicators to main Tables 1 and
  3, following Human3R's compact table style.
- Added a dedicated appendix table of contents with automatically resolved
  page references for Sections A--E and D.1--D.7.
- Kept all figure content unchanged.

## v036_20260906_final_training_curve

- Established the final model's 72-epoch AvatarReX/THuman training
  configuration as the sole training account.
- Restored the exact relation-correction objective and its 19.62M trainable
  parameters.
- Added a log-recovered training/validation curve and machine-readable source
  values to the supplement.
- Preserved the metric-bearing abstract and all existing result-table values.

## v035_20260905_metric_abstract_and_training_details

- Selected the concrete-metric abstract without inserting unmeasured
  end-to-end runtime placeholders.
- Replaced the grouped Method loss with the exact implemented event objective,
  weights, and term descriptions.
- Added training-source counts, update count, resolution, optimizer schedule,
  precision, and checkpoint policy to Experimental Setup.
- Preserved all retained results and the nine-page main-paper layout.

## v033_20260905_shot3r_bilingual_first_draft

- Adopted the Shot3R title, method name, and alignment--state decoupling
  narrative throughout the compiled manuscript.
- Rewrote Sections 1--5 and added paired Chinese source comments.
- Consolidated Related Work and Experiments, integrated OnlineHMR, and removed
  the standalone Discussion.
- Reorganized the method into Overview, Stateful Online Human Reconstruction,
  Decoupling Alignment from State Propagation, Camera--Human Consistency
  across Shots, and Learning Alignment at Shot Transitions.
- Rebuilt the three main figures and four main tables while retaining source
  images and numerical evidence.
- Fixed main-table horizontal overflow and kept the scientific paper within
  nine pages.

## v031_20260902_read_reset_register_and_baseline_plan

- Adopted the final Read--Reset--Register title and method vocabulary.
- Rewrote the abstract without per-dataset metric enumeration.
- Recast the contributions as four concise claims and added OnlineHMR, TRAM,
  and JOSH to Related Work.
- Preserved every v030 experimental value, denominator, and limitation.

## v030_20260901_fact_audit_and_evidence_revision

- Reframed the method as a causal same-scene camera--human boundary operation
  with an explicit information set and propagated-state invariant.
- Added the temporal-token equation, complete coarse-gauge composition,
  transformation scope, and prediction-only association cost.
- Added data-generated viewpoint-interaction and detector-generalization
  artifacts and integrated them into the main paper and supplement.
- Rebuilt the mechanism table so oracle timing is diagnostic and only the
  causal row is deployable.
- Added dual association denominators and zero active runtime abstention.
- Retained Harmony4D W degradation, AIST++ anchored-root degradation,
  repeated-cut camera drift, and MVHuman early detector triggers.
- Added final recoverable training settings and preserved unknown
  hardware/duration/multi-seed details as explicit limitations.
- Included AI Use, Ethics, and Reproducibility statements before References.
- Verified nine scientific pages and one continuous 28-page combined PDF.

## v029_20260830_mvhuman_audit_and_submission_package

- Added the held-out MVHuman stress audit, portable source package, and real
  extreme-view qualitative comparison.
- Preserved public-method support limitations and complete negative results.
